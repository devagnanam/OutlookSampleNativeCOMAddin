
if ("" eq $ARGV[0])
{
	die "Must include source file\n";
}

open(infile, "$ARGV[0]");
open(outfile, ">>tmp.txt");

while(<infile>) { 
        s/\s+$//; 
        print outfile "$_\n"; 
} 
close(outfile);
close(infile);
unlink("$ARGV[0]");
rename("tmp.txt","$ARGV[0]");
